let forum=document.getElementById("myform");
let date_valide=true;
forum.addEventListener("submit", function(event) {
    if(date_valide==false)
        event.preventDefault();
    else{
        localStorage.setItem("nume",document.getElementById("fname").value);
        localStorage.setItem("telefon",document.getElementById("tele").value);
        localStorage.setItem("facebook",document.getElementById("url").value);
        localStorage.setItem("culoare",document.getElementById("colorr").value);

    }
}); 

function validate(){
    let ok=0
    var regName = /^[A-Za-z]+(?:\s[A-Za-z]+)?$/;
    var regtel= /^[0-9]+$/;
    var name = document.getElementById('fname').value;
    var tel = document.getElementById('tele').value;
    if(!regName.test(name)){
        console.log("Numele nu este valid");
        document.getElementById('nume_complet').setAttribute("style","color:red;")
        date_valide=false;
        document.getElementById('fname').focus();
       ok=ok+1;
    }
    else{
    date_valide=true;
}
    if(!regtel.test(tel)){
        console.log("Numarul de telefon nu este valid");
        document.getElementById('telefon').setAttribute("style","color:red;")
        date_valide=false;
        document.getElementById('telefon').focus();
       ok=ok+1;
    }
    else{   
    date_valide=true;         
    }
    if(ok==0){
        return true;
    }
    return false;
}


let light=false;
let buton = document.getElementById("switch");
buton.addEventListener("click", function darkmodefunction() {
    if(light==false){
        light=true;
    }
    else if(light==true){
        light=false;
    console.log("buton apasat");
    var divv=document.querySelectorAll("div");
    var h=document.querySelectorAll("h2");
    body=document.body;

    if (body.style.backgroundColor == "") {
        console.log("e pe withe mode");
        body.setAttribute("style", "background-color:rgb(240, 177, 244);")
        for (var p = 0; p < divv.length; p++) {
            divv[p].setAttribute("style", "color:black;")
        }
        for (var p = 0; p < h.length; p++) {
            h[p].setAttribute("style", "color:black;")
        }
    }

    else {
        console.log("e pe dark mode");
        body.style.backgroundColor = "";
        for (var p = 0; p < divv.length; p++) {
            divv[p].style.color = "";
        }
        for (var p = 0; p < h.length; p++) {
            h[p].style.color = "";
        }
    }
    }
});



window.imagesparkel = function(e) {
    e.target.style.filter = "brightness(150%)";
    e.target.style.filter = "sepia(100%)";
    e.stopPropagation();
}

window.normalimage = function(e) {
    e.target.style.filter = "brightness(100%)";
    e.stopPropagation();
}




window.addEventListener("load", function() {
    var radioDa = document.getElementById("huey");
    var radioNu = document.getElementById("dewey");
    var container = document.getElementById("poza_cusca");
  
    radioDa.addEventListener("change", function() {
      // Verificarea dacă radio button-ul "Da" este bifat
      if (radioDa.checked) {
        // Crearea unui nou element div pentru cusca animalului
        var cuscaDiv = document.createElement("div");
        cuscaDiv.id = "cuscaDiv";
  
        // Crearea elementului pentru încărcarea pozei cusci
        var pozaLabel = document.createElement("label");
        pozaLabel.textContent = "Poza cusca:";
        var pozaInput = document.createElement("input");
        pozaInput.setAttribute("type", "file");
        pozaInput.setAttribute("name", "poza");
  
        // Adăugarea elementelor în cuscaDiv
        cuscaDiv.appendChild(pozaLabel);
        cuscaDiv.appendChild(pozaInput);
  
        // Adăugarea cuscaDiv în container
        container.appendChild(cuscaDiv);
      }
    });
  
    radioNu.addEventListener("change", function() {
      // Verificarea dacă radio button-ul "Nu" este bifat
      if (radioNu.checked) {
        // Dacă radio button-ul "Nu" este bifat, se șterge cuscaDiv (dacă există)
        var cuscaDiv = document.getElementById("cuscaDiv");
        if (cuscaDiv) {
          cuscaDiv.parentNode.removeChild(cuscaDiv);
        }
      }
    });
  });
  