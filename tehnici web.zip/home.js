var h1Elements = document.querySelectorAll("h1");
var intervalId;

// Funcția pentru schimbarea culoreii textului
function toggleShineEffect() {
  for (var i = 0; i < h1Elements.length; i++) {
    var h1Element = h1Elements[i];
    var currentColor = window.getComputedStyle(h1Element).color;
    var newColor = currentColor === 'rgb(231, 198, 255)' ? 'rgb(182, 143, 255)' : 'rgb(231, 198, 255)';
    h1Element.style.color = newColor;
  }
}

// Setează intervalul pentru a apela funcția la fiecare 5 secunde
intervalId = setInterval(toggleShineEffect, 5000);
