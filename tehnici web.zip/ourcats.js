var catImages = ["da.jpg", "LatteArtcat.jpg", "MostlyCatsMostly.jpg", "white.png", "morectas.jpg", "blaccat.jpeg","flufffy.jpg"]; // Lista de imagini cu pisici
    var currentImageIndex = 0; 

    function changeCatImage() {
      var catImg = document.getElementsByClassName("imagini")[0];
      catImg.src = catImages[currentImageIndex]; 
      
      currentImageIndex++;
      if (currentImageIndex >= catImages.length) {
        currentImageIndex = 0; 
      }
    }

    setInterval(changeCatImage, 3000); 

  function translate() {
    var buton_e = document.createElement("button");
    var place_buton= document.getElementsByClassName("despartitor")[0];
    place_buton.appendChild(buton_e);
    buton_e.textContent="Tradu in engleza";
    buton_e.style.backgroundColor=" rgba(200, 182, 255)";
    buton_e.style.color=" #370a42";
    buton_e.style.border="2px solid   rgb(9, 9, 9)";
    buton_e.style.borderRadius="5px";

    let tex_eng=["A little slide-show with our cats!","Welcome to MeowCaffe, the place where you will discover the most adorable cats! Whether playful, sleepy or full of personality, our cats are sure to win you over." ];
    let tex_rom=["Un mic slide-show cu pisicile noastre!", "Bine ați venit la MeowCaffe, locul în care veți descoperi cele mai adorabile pisici! Fie că sunt jucause, somnoroase sau pline de personalitate, pisicile noastre sunt sigure să vă cucerească."];
    var tradus=false;
    buton_e.addEventListener("click", function(){
      var fig_caption=document.getElementsByTagName("figcaption");
      var footer=document.getElementsByTagName("footer")[0];
      if(tradus==false){
        for(var i=0;i<fig_caption.length;i++){
          fig_caption[i].textContent=tex_rom[i];
          
        }
        tradus=true;
        footer.textContent = " 🐾 Ne rezervăm dreptul de a ne selecta clientela. Toți iubitorii de animale sunt bineveniți. 🐾";
      }
      else{
        for(var i=0;i<fig_caption.length;i++){
          fig_caption[i].textContent=tex_eng[i];
         
        }
        tradus=false;
        footer.textContent = " 🐾 We reserve the right to select our clientele. All animal lovers are welcome. 🐾"; 
      }
    });
  }
  translate();