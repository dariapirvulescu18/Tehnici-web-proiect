window.addEventListener('DOMContentLoaded', (event) => {
  const canvas = document.getElementById('canvas');
  const context = canvas.getContext('2d');

  const wheelRadius = canvas.width / 5 - 10;
  const centerX = canvas.width / 5;
  const centerY = canvas.height / 5;

  // Define the sections of the wheel
  const sections = [
    { label: 'Prize 1', color: '#FF00FF' }, // Magenta
    { label: 'Prize 2', color: '#DD00FF' }, // Orchid
    { label: 'Prize 3', color: '#AA00FF' }, // Purple
    { label: 'Prize 4', color: '#8800FF' }, // Dark Violet
    { label: 'Prize 5', color: '#6600FF' }, // Indigo
    { label: 'Prize 6', color: '#4400FF' }, // Blue Violet
    { label: 'Prize 7', color: '#2200FF' }, // Blue
    
    // Add more sections as needed
  ];

  // Calculate the angle for each section
  const angle = (2 * Math.PI) / sections.length;

  // Draw the wheel
  sections.forEach((section, index) => {
    const startAngle = index * angle;
    const endAngle = (index + 1) * angle;

    context.beginPath();
    context.moveTo(centerX, centerY);
    context.arc(centerX, centerY, wheelRadius, startAngle, endAngle);
    context.closePath();

    context.fillStyle = section.color;
    context.fill();

    // Draw section labels
    context.save();
    context.translate(centerX, centerY);
    context.rotate(startAngle + angle / 2);
    context.textAlign = 'center';
    context.fillStyle = '#ffffff';
    context.font = 'bold 10px Arial';
    context.fillText(section.label, wheelRadius / 2, 0);
    context.restore();
  });
});
