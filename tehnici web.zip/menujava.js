
  window.addEventListener('DOMContentLoaded', (event) => {
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');
  
    const wheelRadius = canvas.width / 2 - 10;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
  
    
    const sections = [
      { label: 'Prize 1', color: '#FF00FF' },  
      { label: 'Prize 2', color: '#DD00FF' }, 
      { label: 'Prize 3', color: '#AA00FF' }, 
      { label: 'Prize 4', color: '#8800FF' }, 
      { label: 'Prize 5', color: '#6600FF' }, 
      { label: 'Prize 6', color: '#4400FF' }, 
      { label: 'Prize 7', color: '#2200FF' }, 
      
      
    ];
  
    
    const angle = (2 * Math.PI) / sections.length;
  
    
    sections.forEach((section, index) => {
      const startAngle = index * angle;
      const endAngle = (index + 1) * angle;
  
      context.beginPath();
      context.moveTo(centerX, centerY);
      context.arc(centerX, centerY, wheelRadius, startAngle, endAngle);
      context.closePath();
  
      context.fillStyle = section.color;
      context.fill();
  
     
      context.save();
      context.translate(centerX, centerY);
      context.rotate(startAngle + angle / 2);
      context.textAlign = 'center';
      context.fillStyle = '#ffffff';
      context.font = 'bold 30px Arial';
      context.fillText(section.label, wheelRadius / 2, 0);
      context.restore();


      
      
    });
  });
  
  window.imagespin = function(e) {
    console.log("test");  
    if (e.key === "Enter") {
      const puncteBonus = Math.floor(Math.random() * 10) + 1;
      alert("Ai castigat " + puncteBonus + " % discount la orice bautura de pe meniu!");
    }
  };